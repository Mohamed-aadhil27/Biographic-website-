import React from 'react';
import { Github, Twitter, Linkedin, Mail, ExternalLink } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <div 
        className="h-[60vh] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://www.shutterstock.com/image-illustration/dr-apj-abdul-kalam-portrait-600nw-2310267175.jpg")',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60">
          <div className="container mx-auto px-6 h-full flex items-center">
            <div className="max-w-3xl">
              <h1 className="text-5xl md:text-7xl font-bold mb-4 animate-fade-in">
              Dr. APJ Abdul Kalam
              </h1>
              <p className="text-xl md:text-2xl text-gray-300 mb-8">
                Missile Man of India
              </p>
              
            </div>
          </div>
        </div>
      </div>

      {/* Bio Section */}
      <div className="container mx-auto px-6 py-20">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl font-bold mb-6">About </h2>
            <p className="text-gray-300 leading-relaxed mb-6">
             Dr. APJ Abdul Kalam: The People's President and Missile Man of India
Full Name: Avul Pakir Jainulabdeen Abdul Kalam
Born: October 15, 1931
Died: July 27, 2015
Birthplace: Rameswaram, Tamil Nadu, India

Dr. APJ Abdul Kalam, fondly known as the Missile Man of India and the People's President, was an Indian scientist, educator, author, and the 11th President of India. Renowned for his humility, integrity, and passion for innovation, Dr. Kalam's legacy continues to inspire millions worldwide.
            </p>
            <p className="text-gray-300 leading-relaxed mb-6">
              Early Life and Education:
Born into a modest family in Rameswaram, Tamil Nadu, Dr. Kalam’s early years were shaped by financial struggles, but his parents instilled in him the values of education and perseverance. Despite these challenges, he excelled academically, eventually studying physics at St. Joseph’s College, Tiruchirappalli, and later earning a degree in aerospace engineering from the Madras Institute of Technology (MIT).


            </p>
             <p className="text-gray-300 leading-relaxed mb-6">
              Scientific Career and Contributions:
Dr. Kalam’s career as a scientist began at the Indian Space Research Organisation (ISRO), where he played a key role in India’s space programs. His groundbreaking work included the development of India’s first satellite launch vehicle (SLV), which successfully launched the Rohini satellite into space.

He went on to lead the Integrated Guided Missile Development Programme (IGMDP) at the Defence Research and Development Organisation (DRDO). His efforts led to the development of the Agni and Prithvi missiles, which earned him the title of Missile Man.

Dr. Kalam was also instrumental in India’s Pokhran-II nuclear tests (1998), which established India as a nuclear power.
            </p>
            <p className="text-gray-300 leading-relaxed mb-6">
              Presidency of India:
Dr. Kalam was elected as the 11th President of India in 2002, serving from 2002 to 2007. During his presidency, he earned the affection and admiration of people across the country for his simplicity, approachability, and strong focus on youth development. Often referred to as the People’s President, he actively engaged with young Indians, inspiring them to dream big and work hard to make their dreams a reality.

One of his most notable contributions during his presidency was his vision for a developed India by 2020, outlined in his famous book, "India 2020". His leadership and emphasis on education, innovation, and national development continue to influence India's progress today.
            </p>
            <p className="text-gray-300 leading-relaxed mb-6">
              Philosophy and Vision
Dr. Kalam was a firm believer in the power of youth and education. He encouraged students to work towards creating a scientific and technological revolution in India, often urging them to dream, dream, dream and reach for the stars. His vision was to transform India into a developed nation through education, technological advancement, and national unity.
            </p>
            <p className="text-gray-300 leading-relaxed mb-6">
               Author and Educator:
Dr. Kalam was also an accomplished author. His autobiography, "Wings of Fire," is an inspirational account of his early life, struggles, and achievements. His other books, including "Ignited Minds", "The Life Tree", and "India 2020", continue to motivate millions, especially the youth, to pursue excellence.

Beyond writing, Dr. Kalam was deeply involved in education. He served as a professor at various universities and delivered lectures across the country. His focus on developing the next generation of leaders and thinkers made him one of India’s most beloved educators.
            </p>
            
          </div>
          <div>
            <h2 className="text-3xl font-bold mb-6"> Awards and Honors</h2>
            <div className="space-y-6">
              <ExperienceItem
                title=" Bharat Ratna:"
                company="Bharath Ratna"
                period="1997"
                description="The Bharat Ratna is India's highest civilian award, given for exceptional service in the fields of art, literature, science, and public service. Dr. Kalam received this award for his outstanding contribution to the nation's defense and space programs."
              />
              <ExperienceItem 
                title="Padma Vibhushan "
                company="Padma Vibhushan"
                period="1990"
                description="The Padma Vibhushan is India's second-highest civilian award, presented for exceptional and distinguished service in any field. Dr. Kalam was honored with this award for his contributions to science and technology."
              />
              <ExperienceItem 
                title="Padma Bhushan"
                company="Padma Bhushan"
                period="1981"
                description="The Padma Bhushan is the third-highest civilian award in India, presented for distinguished service in various fields, including science, arts, public affairs, and more. Dr. Kalam received this award for his work in the fields of defense and space technology."
              />
               <ExperienceItem 
                title="Indira Gandhi Award for National Integration "
                company="Indira Gandhi Award for National Integration"
                period="1997"
                description="Dr. Kalam received the Indira Gandhi Award for National Integration for his efforts in promoting national unity and integration through science and technology."
              />
               <ExperienceItem 
                title="Veer Savarkar Award"
                company="Veer Savarkar Award"
                period="1998"
                description="This award recognized Dr. Kalam's contributions to India's defense and missile programs."
              />
               <ExperienceItem 
                title="Ramanujan Award"
                company="Ramanujan Award"
                period="2000"
                description="Dr. Kalam was awarded the Ramanujan Award for his contributions to scientific research and development, especially in the field of missile technology."
              />
               <ExperienceItem 
                title="King Charles II Medal "
                company="King Charles II Medal "
                period="2007"
                description="Dr. Kalam received the King Charles II Medal for his exceptional contributions to the field of science and his work in improving relations between India and the UK."
              />
               <ExperienceItem 
                title="The Hoover Medal"
                company="The Hoover Medal"
                 period="2009"
                description="Dr. Kalam was awarded the Hoover Medal, a prestigious international award for his contribution to engineering and technology. The award is presented for notable achievements in the development of humanity."
              />
               <ExperienceItem 
                title=" International Fellowships"                
                description="Dr. Kalam was also made an honorary fellow of various prestigious institutions, including:
                 
The Royal Society of the UK,
                 
The American Institute of Aeronautics and Astronautics,
                 
The Royal Academy of Engineering."
               />  
                 <ExperienceItem 
                title="United Nations Award"
                description="He was honored with a special recognition for his contributions to education and technology."
              />
               <ExperienceItem 
                title="Honorary Doctorates"
                description="Dr. Kalam was conferred honorary doctorates by several prestigious institutions, including:
Harvard University,
Yale University,
University of Edinburgh,
IITs (Indian Institutes of Technology),
University of Sri Jayewardenepura (Sri Lanka)."
              />
              
            </div>
          </div>
        </div>
      </div>

      {/* Projects Section */}
      <div className="bg-gray-800 py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12"></h2>
          <div className="grid md:grid-cols-3 gap-8">
            <ProjectCard 
              title="Early Life & Education"
              description="Abdul Kalam came from a humble background. His father, Jainulabdeen, was a boat owner, and his mother, Ashiamma, was a homemaker.
He was an excellent student, and he showed an early interest in flying and science.
He graduated in physics from St. Joseph's College, Tiruchirappalli, and later earned a degree in aeronautical engineering from the Madras Institute of Technology (MIT)."
               link="#"
            />
            <ProjectCard 
              title="Scientific Contributions"
              description="Kalam was a key figure in India's civilian space program and military missile development.He worked at the Indian Space Research Organisation (ISRO) and the Defence Research and Development Organisation (DRDO).
He played an important role in India's first satellite launch vehicle (SLV) and the development of the country's ballistic missile program.
His work on the Agni and Prithvi missiles earned him the nickname. 'Missile Man of India'."
              link="#"
            />
            <ProjectCard 
              title="Legacy"
              description="Dr. Kalam's life and work continue to inspire millions of Indians. He is particularly remembered for his vision of an empowered India, driven by technological advancement and the empowerment of its youth.
On July 27, 2015, Dr. Kalam passed away while giving a lecture at the Indian Institute of Management Shillong. His death was widely mourned, and he is remembered as a visionary who had a lasting impact on India's scientific community and its national development."
              link="#"
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 py-8">
        <div className="container mx-auto px-6 text-center text-gray-400">
          <p>© 2024 John Anderson. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function SocialLink({ href, icon }: { href: string; icon: React.ReactNode }) {
  return (
    <a 
      href={href}
      className="w-12 h-12 rounded-full bg-white bg-opacity-20 flex items-center justify-center
                 hover:bg-opacity-30 transition-all duration-300"
    >
      {icon}
    </a>
  );
}

function ExperienceItem({ 
  title, 
  company, 
  period, 
  description 
}: { 
  title: string;
  company: string;
  period: string;
  description: string;
}) {
  return (
    <div className="border-l-2 border-gray-700 pl-4">
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="text-gray-400">{company} • {period}</p>
      <p className="text-gray-300 mt-2">{description}</p>
    </div>
  );
}

function ProjectCard({ 
  title, 
  description, 
  link 
}: { 
  title: string;
  description: string;
  link: string;
}) {
  return (
    <div className="bg-gray-900 p-6 rounded-lg hover:transform hover:-translate-y-1 transition-all duration-300">
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-400 mb-4">{description}</p>
      <a 
        href={link} 
        className="inline-flex items-center text-blue-400 hover:text-blue-300"
      >
        Learn more <ExternalLink className="ml-1 w-4 h-4" />
      </a>
    </div>
  );
}

export default App;